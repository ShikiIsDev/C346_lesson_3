package sg.edu.rp.c346.id21024483.billplease;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    TextView tvDisplayTotal;
    TextView tvDisplayEach;
    Button btnDisplaySplit;
    Button btnDisplayReset;
    EditText etInputAmount;
    EditText etInputNumOfPax;
    EditText etInputDiscount;
    ToggleButton tbtnSVS;
    ToggleButton tbtnGST;
    RadioGroup rgPayment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvDisplayTotal = findViewById(R.id.textViewTotal);
        tvDisplayEach = findViewById(R.id.textViewEach);
        btnDisplaySplit = findViewById(R.id.split);
        btnDisplayReset = findViewById(R.id.reset);
        etInputAmount = findViewById(R.id.totalAmount);
        etInputNumOfPax = findViewById(R.id.numOfPax);
        etInputDiscount = findViewById(R.id.discount);
        tbtnSVS = findViewById(R.id.svs);
        tbtnGST = findViewById(R.id.gst);
        rgPayment = findViewById(R.id.pMethod);

        btnDisplaySplit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String stringAmnt = etInputAmount.getText().toString();
                String stringNumPax = etInputNumOfPax.getText().toString();
                if (stringAmnt.isEmpty() || stringNumPax.isEmpty()) {
                    Toast.makeText(MainActivity.this,
                            "Please input the amount/ number of people",
                            Toast.LENGTH_SHORT).show();
                } else {
                    if (etInputAmount.getText().toString().trim().length() != 0 && etInputNumOfPax.getText().toString().trim().length() !=0 ) {
                        double newAmnt = 0.0;
                        if (!tbtnSVS.isChecked() && !tbtnGST.isChecked()) {
                            newAmnt = Double.parseDouble(etInputAmount.getText().toString());
                        } else if (tbtnSVS.isChecked() && !tbtnGST.isChecked()) {
                            newAmnt = Double.parseDouble(etInputAmount.getText().toString())*1.1;
                        } else if (!tbtnSVS.isChecked() && tbtnGST.isChecked()) {
                            newAmnt = Double.parseDouble(etInputAmount.getText().toString())*1.07;
                        } else {
                            newAmnt = Double.parseDouble(etInputAmount.getText().toString())*1.17;
                        }
                        if (etInputDiscount.getText().toString().trim().length() != 0) {
                            newAmnt += 1 - Double.parseDouble(etInputDiscount.getText().toString())/100;
                        }
                        tvDisplayTotal.setText("Total Bill: $"+ String.format("%.2f", newAmnt));

                        int numP = Integer.parseInt(etInputNumOfPax.getText().toString());
                        int checkPaymethod = rgPayment.getCheckedRadioButtonId();
                        if(numP != 0) {
                            if (checkPaymethod == R.id.pMethod) {
                                String txtCash = " in cash.";
                                tvDisplayEach.setText("Each Pays: $"+String.format("%.2f", newAmnt / numP) + txtCash);
                            } else {
                                String txtPaynow = "via PayNow to 912345678";
                                tvDisplayEach.setText("Each Pays: $"+String.format("%.2f",newAmnt / numP) + txtPaynow);
                            }
                        } else {
                            tvDisplayEach.setText("Negative number entered. Please try again. ");
                        }
                    }
                }
            }
        });

        btnDisplayReset.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                etInputAmount.setText(" ");
                etInputNumOfPax.setText(" ");
                tbtnSVS.setChecked(false);
                tbtnGST.setChecked(false);
                etInputDiscount.setText(" ");
            }
        });

    }
}